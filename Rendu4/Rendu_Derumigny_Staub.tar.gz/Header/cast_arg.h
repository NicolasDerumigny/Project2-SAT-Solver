#ifndef CAST_ARG_H
#define CAST_ARG_H
#include <string.h>
#include <algorithm>
#include "global_variable_extern.h"

void cast_arg(int argc, char** argv);

#endif // CAST_ARG_H
